/** @file course.h
 * @author Saad Tariq
 * @date 2022-04-12
 * @brief Header file used to store the type declaration for the `Course` type and various function declarations for the `Course` type
 * @details **Additional Details**
 * - typedef declaration of a `Course` type based on the struct `_course`
 * - function declaration of `enroll_student`
 * - function declaration of `print_course`
 * - function declaration of `top_student`
 * - function declaration of `passing`
 */

#include "student.h"
#include <stdbool.h>

// /**
//  *  @typedef _course Course
//  *  @brief Course type based on definition of _course struct
//  *  @struct _course
//  *  @brief This structure is used to define the Course type with fields name, code, students, total_students.
//  */

/**
 * Course type stores a _course with fields,
 * - name
 * - code
 * - students
 * - total_students
 */
typedef struct _course
{
  char name[100];     /**< Name of the course */
  char code[10];      /**< Course code */
  Student *students;  /**< Pointer to an array of student's, which are members of the course */
  int total_students; /**< Count to keep track of the total number of students in the course*/
} Course;

/**
 * @brief Enroll a student into a Course
 *
 * @param course
 * pointer to the course in which the student will be enrolled in
 * @param student
 * pointer to the student the will be enrolled in the course
 * @return nothing
 */
void enroll_student(Course *course, Student *student);
/**
 * @brief Print out the name of the course, the course code, and the students in the course
 *
 * @param course
 * pointer to the course which will have its details printed
 * @return nothing
 */
void print_course(Course *course);
/**
 * @brief Determine the student with the highest grade in the course
 *
 * @param course
 * pointer to the course
 * @return
 * pointer to the student with the highest grade
 */
Student *top_student(Course *course);
/**
 * @brief Determine the students which are passing the course
 *
 * @param course
 * pointer to the course
 * @param total_passing
 * pointer to the total count of passing students
 * @return
 * pointer to the array of students which are passing the course
 */
Student *passing(Course *course, int *total_passing);
