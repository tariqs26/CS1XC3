/** @file course.c
 * @author Saad Tariq
 * @date 2022-04-12
 * @brief File used define various function declarations for the `Course` type located in course.h
 * @details **Additional Details**
 * - function definition of `enroll_student`
 * - function definition of `print_course`
 * - function definition of `top_student`
 * - function definition of `passing`
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Enroll a student into a Course
 *
 * @param course
 * pointer to the course in which the student will be enrolled in
 * @param student
 * pointer to the student the will be enrolled in the course
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  // if the course had no prior students
  // then dynamically allocate a new block of memory capable of storing one student
  if (course->total_students == 1)
  {
    course->students = calloc(1, sizeof(Student));
  }
  // else reallocate the existing block of memory with the updated number of students
  // since the course will have existing students in memory
  // they should be preserved in their respective places
  else
  {
    course->students =
        realloc(course->students, course->total_students * sizeof(Student));
  }
  // update the value at the newly created index, with the new student
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Print out the name of the course, the course code, and the students in the course
 *
 * @param course
 * pointer to the course which will have its details printed
 * @return nothing
 */
void print_course(Course *course)
{
  // print the course name, code and total student count
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");

  // loop through each student in the course
  // printing out the student by passing in their address to print_student function
  for (int i = 0; i < course->total_students; i++)
    print_student(&course->students[i]);
}

/**
 * @brief Determine the student with the highest grade in the course
 *
 * @param course
 * pointer to the course
 * @return
 * pointer to the student with the highest grade
 */
Student *top_student(Course *course)
{
  // no students in the course return NULL pointer
  if (course->total_students == 0)
    return NULL;

  double student_average = 0;
  // initialize max to the average of the first student in the course
  double max_average = average(&course->students[0]);
  // current student is initalized to the first student in the course
  Student *student = &course->students[0];

  // for each student in the course, not including the first one
  for (int i = 1; i < course->total_students; i++)
  {
    // student_average, is updated to the current student in the each iteration
    student_average = average(&course->students[i]);
  // if that average is greater than the maximum average
  // update the max_average and student to be returned
    if (student_average > max_average)
    {
      max_average = student_average;
      student = &course->students[i];
    }
  }
  // return the pointer to the student with the maximum average in the course
  return student;
}

/**
 * @brief Determine the students which are passing the course
 *
 * @param course
 * pointer to the course
 * @param total_passing
 * pointer to the total count of passing students
 * @return
 * pointer to the array of students which are passing the course
 */
Student *passing(Course *course, int *total_passing)
{
  // initialize count to 0, and pointer to passing students to NULL
  int count = 0;
  Student *passing = NULL;

  // for each of the students in the course, if the students average is >= 50, increment the count
  for (int i = 0; i < course->total_students; i++)
    if (average(&course->students[i]) >= 50)
      count++;

  // dynamically allocate a block of memory assigned to the passing pointer
  // with the size of the amount of passing students
  passing = calloc(count, sizeof(Student));

  // passing count
  int j = 0;
  // for each student in the course, if the student is passing
  // add them to the passing students memory block, and increment the passing count
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++;
    }
  }

  // value at total_passing set to the the number of passing students
  *total_passing = count;

  // return the pointer to the dynamically allocated memory block
  // containing the students that are passing the course
  return passing;
}