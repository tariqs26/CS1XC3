/** @file student.c
 * @author Saad Tariq
 * @date 2022-04-12
 * @brief File used define various function declarations for the `Student` type located in student.h
 * @details **Additional Details**
 * - function definition of `add_grades`
 * - function definition of `average`
 * - function definition of `print_student`
 * - function definition of `generate_random_student`
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Add a grade to a students array of grades
 *
 * @param student
 * pointer to student who will have a grade added to their array of grades
 * @param grade
 * value of the grade being added to the students grades
 * @return nothing
 */
void add_grade(Student *student, double grade)
{
  // increment the number of grades a student has
  student->num_grades++;

  // if the student had no prior grades
  // then dynamically allocate a new block of memory capable of storing one grade
  if (student->num_grades == 1)
    student->grades = calloc(1, sizeof(double));
  // else reallocate the existing block of memory used to store grades with the updated grade size
  // since the student will have existing grades in memory
  // they should be preserved in their respective places 
  else
  {
    student->grades =
        realloc(student->grades, sizeof(double) * student->num_grades);
  }
  // update the value at the newly created index, with the grade argument
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Calculate a students average based on all of their grades
 *
 * @param student
 * pointer to student whose average will be calculated
 * @return Student's numerical average of grades, 0 if no grades present
 */
double average(Student *student)
{
  // if the student has no grades, return 0
  if (student->num_grades == 0)
    return 0;

  // keep track of sum of grades
  double total = 0;
  // loop through each of the students grade, incrementing the total sum of grades
  for (int i = 0; i < student->num_grades; i++)
    total += student->grades[i];
  // return the sum of grades divided by the number of grades, which is the average
  return total / ((double)student->num_grades);
}

/**
 * @brief Print out, a student's name, ID, list of grades and average
 *
 * @param student
 * pointer to the student
 * @return nothing
 */
void print_student(Student *student)
{
  // print the name,ID of the student
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // loop through each grade in the students grades array, printing out the value
  for (int i = 0; i < student->num_grades; i++)
    printf("%.2f ", student->grades[i]);
  printf("\n");
  // print the average of the student
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Generate a new Student object
 * with a randomly generated:
 * - First and last name, each of which can be 1 of 24 unique options
 * - 10 digit student ID with randomly generated digits from 0-9
 * - List of grades, with the size specified by the grades paramater
 *  - Each grade which can have a randomly generated value of 25-99%
 *
 * @param grades
 * number of grades that should be generated to be added to the student's grades
 * @return
 * pointer to the newly created Student
 */
Student *generate_random_student(int grades)
{
  // list of first names
  char first_names[][24] =
      {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
       "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
       "Julie", "Omar", "Yousef", "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  // list of last names
  char last_names[][24] =
      {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams",
       "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat",
       "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};

  // dynamically allocate a new block of memory capable of storing 1 Student
  Student *new_student = calloc(1, sizeof(Student));

  // randomly generate a number from 0-23, 2 times
  // based on the value at the index represented by the generated number
  // update the students first name and last name
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // generate a students id, by generating 10 random ascii characters representing digits from 0-9
  // rand() % 10, can be 0 to a max of 9,
  // so the ascii values will be from (48+0) - (48+9) which represents 0-9
  for (int i = 0; i < 10; i++)
    new_student->id[i] = (char)((rand() % 10) + 48);
  // null terminating string character
  new_student->id[10] = '\0';

  // generate the number of grades, specified by the grades parameter
  for (int i = 0; i < grades; i++)
  {
    // add a randomly generated grade to the newly created student's grades
    // with a minimum grade of 25% to a maximum of 99%
    // since rand()%75 can have a minimum value of 0, to a maximum value of 74
    add_grade(new_student, (double)(25 + (rand() % 75)));
  }

  // return the pointer to the newly created student
  return new_student;
}