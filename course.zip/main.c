/** @file main.c
 * @author Saad Tariq
 * @date 2022-04-12
 * @brief main file
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief This function
 * - generates a random seed 
 * - assigns a pointer to a Course
 * - updates the name and course code of the course
 * - enrolls 20 randomly generated students with 8 grades into the course
 * - prints out the name, course code and students of the course
 * - assigns a pointer to the top student in the course, and prints out the student
 * - generates an array of students passing the course, and prints them out
 * 
 * @return int 
 */
int main()
{
  // ensure that the seed is different for every run, since time() will be different for each run
  // this will ensure that the numbers generated from one run to the other will not be identical
  srand((unsigned)time(NULL));

  // dynamically allocate memory to store 1 Course type
  Course *MATH101 = calloc(1, sizeof(Course));

  // update the values of the course name and course code
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // enroll 20 randomly generated students in to the course
  // each of which will have 8 randomly generated grades
  for (int i = 0; i < 20; i++)
    enroll_student(MATH101, generate_random_student(8));

  print_course(MATH101);

  Student *student;
  // student pointer is the same as the pointer to the top student in the course
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // keep track of total count of passing students
  int total_passing;
  // array of students that are passing the course, count is passed by reference
  // so that the value gets updated by the passing function
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");

  // print out all of the students in the passing_students array, by looping through the indicies
  // by passing the address of each student stored in the passing_students array at that index
  for (int i = 0; i < total_passing; i++)
    print_student(&passing_students[i]);

  return 0;
}