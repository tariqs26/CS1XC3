/** @file student.h
 * @author Saad Tariq
 * @date 2022-04-12
 * @brief Header file used to store the type declaration for the `Student` type and various function declarations for the `Student` type
 * @details **Additional Details**
 * - typedef declaration of the `Student` type
 * - function declaration of `add_grades`
 * - function declaration of `average`
 * - function declaration of `print_student`
 * - function declaration of `generate_random_student`
 */

/**
 * Student type stores a _student with fields,
 * - first_name
 * - last_name
 * - id
 * - grades
 * - num_grades
 */
typedef struct _student
{
  char first_name[50]; /**< First name of a student*/
  char last_name[50]; /**< Last name of a student */
  char id[11]; /**< ID number of a student */
  double *grades; /**< Pointer to an array of the student's grades */
  int num_grades; /**< Total number of grades a student has*/
} Student;

/**
 * @brief Add a grade to a students array of grades
 *
 * @param student
 * pointer to student who will have a grade added to their array of grades
 * @param grade
 * value of the grade being added to the students grades
 * @return nothing
 */
void add_grade(Student *student, double grade);
/**
 * @brief Calculate a students average based on all of their grades
 *
 * @param student
 * pointer to student whose average will be calculated
 * @return Student's numerical average of grades, 0 if no grades present
 */
double average(Student *student);
/**
 * @brief Print out, a student's name, ID, list of grades and average
 *
 * @param student
 * pointer to the student
 * @return nothing
 */
void print_student(Student *student);
/**
 * @brief Generate a new Student object
 * with a randomly generated:
 * - First and last name, each of which can be 1 of 24 unique options
 * - 10 digit student ID with randomly generated digits from 0-9
 * - List of grades, with the size specified by the grades paramater
 *  - Each grade which can have a randomly generated value of 25-99%
 *
 * @param grades
 * number of grades that should be generated to be added to the student's grades
 * @return
 * pointer to the newly created Student
 */
Student *generate_random_student(int grades);
